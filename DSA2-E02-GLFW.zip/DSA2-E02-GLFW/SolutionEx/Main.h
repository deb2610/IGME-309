//#pragma once
/*-------------------------------------------------------------------------------------------------- 
Declan E. Behan
DSA 2 Section 2

This is the example solution!

This project was generated in 2019
--------------------------------------------------------------------------------------------------*/ 
#ifndef _MAIN_H 
#define _MAIN_H

#include <iostream>
//Include standard headers
#include <stdio.h>
#include <stdlib.h>
#include "GL\glew.h"
#include "GLFW\glfw3.h"
#include "GLM\glm.hpp"
#include "OpenGL-Tutorials\shader.hpp"

#endif //_MAIN_H