Hello there Ash/Beau! Pleasure to make your digital aquaintance!

So heres my readme for HW1 - Templated Queue

In my Main.cpp, I go through the process of pushing and popping things to the queue 
with intermittent breaks for printing to show evidence that its actually working.


I have the following methods/functions in TemplatedQueue.h that matter for grading:

Rule of Three - Constructor
	- Line 49

Rule of Three - Copy Constructor
	- Line 59

Rule of Three - Copy Operator
	- Line 75
	
Rule of Three - Destructor
	- Line 281
	
Push
	- Line 106

Pop
	- Line 154

Print
	- Line 176

GetSize
	- Line 231

IsEmpty
	- Line 274

Sorting
	- Line 192
	
I'm not honestly sure what else is expected from this readme. Let me know in 
MyCources feedback if I need to include more next time.

Have a great day!

- Declan Behan

