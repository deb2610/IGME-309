//#pragma once
/*-------------------------------------------------------------------------------------------------- 
Declan E. Behan
DSA 2 Section 2

This is the example solution!

This project was generated in 2019
--------------------------------------------------------------------------------------------------*/ 
#ifndef _MAIN_H 
#define _MAIN_H

#include <iostream>

#endif //_MAIN_H