/*-------------------------------------------------------------------------------------------------- 
Declan E. Behan
DSA 2 Section 2

This is the example solution!
--------------------------------------------------------------------------------------------------*/ 
#include "Main.h"

int main() {
	std::cout << "Hello World\n";
	//Ending the program 
	std::cout << "Press enter to finish"; 
	getchar(); 
	return 0; 
}